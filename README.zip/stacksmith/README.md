# StackSmith

> AI-powered MACH architecture generator for composable commerce — built for the **Nebius x NVIDIA Global AI Hackathon**.

[![Powered by NVIDIA Nemotron](https://img.shields.io/badge/Powered%20by-NVIDIA%20Nemotron%203%20Super-76b900?logo=nvidia)](https://www.nvidia.com)
[![Nebius Token Factory](https://img.shields.io/badge/Nebius-Token%20Factory-0055ff)](https://tokenfactory.nebius.com)

## What It Does

StackSmith turns a business requirement into a production-ready MACH architecture recommendation in seconds.

Paste a requirement like:
> *"I need a B2B marketplace for industrial parts with multi-vendor catalog, RFQ workflow, and ERP integration with SAP"*

And StackSmith generates:
- **Recommended Stack** — specific tools (commercetools, Contentful, Algolia, Camunda, etc.)
- **Architecture Overview** — how the pieces connect via APIs, webhooks, and events
- **Integration Code** — runnable TypeScript/JavaScript snippets using real SDKs
- **Rationale** — why this stack fits the requirement
- **Estimated Complexity** — Low / Medium / High

## Why This Matters

Solutions architects at Global Systems Integrators (GSIs) spend hours scoping technology stacks for enterprise clients. StackSmith cuts that to seconds, while maintaining the depth and specificity that senior architects demand.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| AI Model | **NVIDIA Nemotron 3 Super (120B)** via Nebius Token Factory |
| Infrastructure | **Nebius Token Factory** — OpenAI-compatible API |
| Backend | Python / Flask |
| Frontend | Vanilla HTML/CSS/JS (dark theme, responsive) |
| Deployment | Vercel / Render / Fly.io |

## Quick Start

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/stacksmith.git
cd stacksmith
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set up your API key
```bash
cp .env.example .env
# Edit .env and add your Nebius API key
```

Get your key at [tokenfactory.nebius.com](https://tokenfactory.nebius.com).

### 4. Run locally
```bash
python app.py
```

Open [http://localhost:5000](http://localhost:5000) in your browser.

## How It Uses Nebius & NVIDIA

- **Nebius Token Factory** serves as the inference endpoint. We use the OpenAI-compatible API (`base_url="https://api.tokenfactory.nebius.com/v1/"`) for seamless integration.
- **NVIDIA Nemotron 3 Super (120B)** is the reasoning engine. We chose Super over Ultra for this use case because architecture generation benefits from fast, cost-efficient reasoning rather than deep mathematical inference. The model understands enterprise patterns (MACH, composable commerce, headless CMS) and generates context-aware integration code.
- **Nebius Serverless Endpoints** (optional) could be used to deploy a fine-tuned version of Nemotron for even more specialized output.

## Example Outputs

### D2C Fashion with AR Try-On
Generates a stack with commercetools, Contentful, 8th Wall WebAR, Next.js on Vercel, and Stripe — including a working Next.js API route that fetches product data with AR model URLs.

### B2B Marketplace with SAP ERP
Generates a stack with commercetools B2B, Camunda Cloud for RFQ workflows, Algolia for search, SAP Integration Suite, and Auth0 — including a TypeScript API route that creates RFQ carts and notifies SAP CPI.

## Demo Video

[Watch the 3-minute demo on YouTube](YOUR_VIDEO_LINK_HERE)

## Hackathon Track

**Best Apps and Agents Track** — StackSmith is a practical, high-performance AI agent that solutions architects would actually use.

## Feedback on Nebius Token Factory & NVIDIA Tools

**What worked brilliantly:**
- The OpenAI-compatible API made integration trivial — zero learning curve. We went from idea to working prototype in under an hour.
- Nemotron 3 Super's reasoning quality for enterprise architecture is surprisingly sharp. It correctly identified niche tools (Camunda for workflows, 8th Wall for AR) and generated SDK-specific code.
- Token Factory's latency is competitive with other providers we've tested.

**What could improve:**
- Native async streaming support would enable real-time architecture diagram generation (imagine watching the stack build line-by-line).
- A dedicated "enterprise architecture" fine-tune of Nemotron could push specificity even further for GSI use cases.

## License

MIT — see [LICENSE](LICENSE).

## Author

Built for the **Nebius x NVIDIA Global AI Hackathon** (October 2026).
